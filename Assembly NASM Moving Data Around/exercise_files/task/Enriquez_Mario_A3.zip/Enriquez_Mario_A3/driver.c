
#include <stdio.h>

extern int asm_main(void);

int main(){

	asm_main();

}
