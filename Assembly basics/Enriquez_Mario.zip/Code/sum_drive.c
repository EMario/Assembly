////////////////////////////////
//
//  Mario Enriquez A00909441
//  COMP 7615
//  Driver for summain assembly
//
////////////////////////////////

#include <stdio.h>

extern int summain(void); //Summain assebly function

void main(){
  summain();  //calls assembly function
}
