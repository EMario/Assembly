README

Minor Issues:
	+Makefile greet64, addsums and sumdrive trgger an error when the command is run, but still create and execute the file correctly. Added an ignore.
	+addsums cannot hndle inputs of 2 digits for some reason but displays 2 digits with no issue
